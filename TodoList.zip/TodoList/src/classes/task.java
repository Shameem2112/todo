package classes;

import javax.swing.*;
import java.awt.*;

public class task extends JPanel {
    private JLabel index;
    private JTextField taskdone;
    private JButton done;
    private boolean checked;

//Construtor
    task(){
        this.setPreferredSize(new Dimension(20,20));
        this.setBackground(Color.RED);
        this.setLayout(new BorderLayout());
        checked= false;
        index = new JLabel();
        index.setPreferredSize(new Dimension(20,20));
        index.setHorizontalAlignment(JLabel.CENTER);
        this.add(index,BorderLayout.WEST);

        taskdone = new JTextField("add your task");
        taskdone.setPreferredSize(new Dimension(20,20));
        taskdone.setLayout(new BorderLayout());
        taskdone.setBorder(BorderFactory.createMatteBorder(2,2,2,2,Color.darkGray));
        taskdone.setBackground(Color.CYAN);
        this.add(taskdone,BorderLayout.CENTER);
        done= new JButton("DONE");
        done.setPreferredSize(new Dimension(20,20));
        done.setLayout(new BorderLayout());
        done.setBorder(BorderFactory.createMatteBorder(2,2,2,2,Color.darkGray));
        done.setBackground(Color.CYAN);
        this.add(done,BorderLayout.SOUTH);
    }
    public  void ChangedState(){
        this.setBackground(Color.GREEN.brighter());
        taskdone.setBackground(Color.GREEN);
        checked= true;

    }
    public JButton getDone(){
        return done;
    }
}
